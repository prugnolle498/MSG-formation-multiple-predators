#### library used for the analyses
library(lme4)
library(car)

#### open the file for each focal species (change the word "species" by the focal species you want to analyse)
obj<-read.table("focal_*species*.txt", sep="\t", header=T)
attach(obj)

####glmm on the response variable MSG_all for the focal species
glmall<-glmer(obj$MSG_all~ (1|reserve)+ season_dry_wet+ lion + leopard + hyenaspotted+ wilddog, family="binomial")
summary(glmallrand)

####test of the correlation between explanatory variables using the VIF 
vif(glmall)

####glmm on the response variable MSG_pair (choose the response variable of interest in the file)
#### in the following, replace the word *pair* by the name of the interacting species (e.g. zebraburchells)
glm_*pair*<-glmer(obj$MSG_*pair*~ (1|reserve)+ *pair*+ season_dry_wet+ lion + leopard + hyenaspotted+ wilddog, family="binomial")

####test of the correlation between explanatory variables using the VIF 
vif(glm_*pair*)

#### create table with numbers of focal species per reserve and number of MSG per interacting species 
#### note that in the resulting table, "0" on the left column means "no interacting species"
table(obj$interacting_species, obj$reserve)